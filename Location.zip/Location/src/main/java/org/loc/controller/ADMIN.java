package org.loc.controller;


import org.loc.entity.UserEntity;
import org.loc.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ADMIN {
	@Autowired
private UserService userservice;
	@PostMapping("/create_data")
	public void Adduser(@RequestBody UserEntity user) {
		userservice.AddUser(user);
	}
	@PutMapping("/update_data/{name}")
	public void updateuser(@RequestBody UserEntity user,@PathVariable String name) {
		userservice.updateUser(user, name);
	}
}


