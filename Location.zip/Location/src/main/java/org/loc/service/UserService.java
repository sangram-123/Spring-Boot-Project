package org.loc.service;

import java.util.ArrayList;
import java.util.List;

import org.loc.Repo.UserRepo;
import org.loc.entity.UserEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserService {
	@Autowired
public UserRepo userrepo;
	public List<UserEntity> getAlluser() {
		ArrayList<UserEntity> list = new ArrayList<UserEntity>();
		userrepo.findAll().forEach(list::add);
		return list;

	}

	public void AddUser(UserEntity user) {
		userrepo.save(user);

	}

	public void updateUser(UserEntity user,String name) {
		userrepo.save(user);
	}
}
