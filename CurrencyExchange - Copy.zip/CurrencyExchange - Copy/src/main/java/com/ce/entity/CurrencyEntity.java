package com.ce.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "CurrencyCoverted")
public class CurrencyEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	private String fromcurrency;

	private String tocurrency;
	@Column(name = "AMOUNT")
	private double amount;
	@Column(name = "RESULT")
	private double convertamount;

	public CurrencyEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CurrencyEntity(String fromcurrency, String tocurrency, double amount, double convertamount) {
		super();

		this.fromcurrency = fromcurrency;
		this.tocurrency = tocurrency;
		this.amount = amount;
		this.convertamount = convertamount;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFromcurrency() {
		return fromcurrency;
	}

	public void setFromcurrency(String fromcurrency) {
		this.fromcurrency = fromcurrency;
	}

	public String getTocurrency() {
		return tocurrency;
	}

	public void setTocurrency(String tocurrency) {
		this.tocurrency = tocurrency;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getConvertamount() {
		return convertamount;
	}

	public void setConvertamount(double convertamount) {
		this.convertamount = convertamount;
	}

}
