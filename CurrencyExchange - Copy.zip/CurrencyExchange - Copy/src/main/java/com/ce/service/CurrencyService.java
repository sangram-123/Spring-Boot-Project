package com.ce.service;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ce.entity.CurrencyEntity;
import com.ce.repository.CurrencyRepository;

@Service
public class CurrencyService {

	private static final String API_URL = "https://api.exchangerate-api.com/v4/latest/";
	@Autowired
	private CurrencyRepository cr;

	public double convertCurrency(String fromCurrency, String toCurrency, double amount) {
		try {
			RestTemplate restTemplate = new RestTemplate();
			String url = API_URL + fromCurrency;
			String response = restTemplate.getForObject(url, String.class);
			JSONObject jsonObject = new JSONObject(response);
			if (!jsonObject.has("rates")) {
				throw new RuntimeException("Error: 'rates' key not found in API response!");
			}

			JSONObject rates = jsonObject.getJSONObject("rates");
			System.out.println("Available currencies: " + rates.keySet());
			if (!rates.has(toCurrency)) {
				throw new RuntimeException("Error: Target currency (" + toCurrency
						+ ") not found in response! Available: " + rates.keySet());
			}

			double exchangeRate = rates.getDouble(toCurrency);
			double convertAmount = amount * exchangeRate;
			CurrencyEntity ce = new CurrencyEntity(fromCurrency, toCurrency, amount, convertAmount);
			cr.save(ce);

			return convertAmount;

		} catch (Exception e) {
			throw new RuntimeException("Failed to fetch exchange rates: " + e.getMessage());
		}
	}
}
