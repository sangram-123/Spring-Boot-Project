package com.ce.controllor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ce.service.CurrencyService;

@Controller
public class CurrencyControllor {
	@Autowired
	private CurrencyService cs;

	@GetMapping("/") // Handle the main page load
	public String showForm() {
		return "currency"; // Load index.html from templates folder
	}

	@PostMapping("/convert")
	public String convertcurrency(@RequestParam String fromcurrency, @RequestParam String tocurrency,
			@RequestParam double amount, Model model) {
		// Double convertedAmount = amount * 86.68;
		// model.addAttribute("result", "Converted Amount: " + convertedAmount);
		double convertedamount = cs.convertCurrency(fromcurrency, tocurrency, amount);
		model.addAttribute("result", "Converted Amount: " + convertedamount);
		return "currency";
	}

}
