package com.ce.controllor;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ce.service.CurrencyService;

@RestController
@RequestMapping("/currency")
public class CurrencyRestControllor {
	@Autowired
	private CurrencyService cs;
	private List<Map<String, Object>> li = new ArrayList();

	@PostMapping("/convert")
	public Map<String, Object> convertCurrencyAPI(@RequestBody Map<String, Object> requestBody) {
		String fromcurrency = (String) requestBody.get("fromcurrency");
		String tocurrency = (String) requestBody.get("tocurrency");
		double amount = (Double) requestBody.get("amount");

		double convertedAmount = cs.convertCurrency(fromcurrency, tocurrency, amount);

		Map<String, Object> result = Map.of("fromcurrency", fromcurrency, "tocurrency", tocurrency, "amount", amount,
				"convertedAmount", convertedAmount);

		li.add(result);

		return result;
	}

	@GetMapping("/read")
	public List<Map<String, Object>> getConversionHistory() {
		return li;
	}
}
