package com.store.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.store.entity.BookEntity;
import com.store.repository.BookRepository;

@Service
public class BookService {
	@Autowired
	private BookRepository repo;

	public void save(BookEntity b) {
		repo.save(b);
	}
	public List<BookEntity> getAllBook(){
		return repo.findAll();
	}
	public BookEntity getBookById( int id) {
		return repo.findById(id).get();
	}
	public void deleteById(int id) {
		repo.deleteById(id);
	}
}
