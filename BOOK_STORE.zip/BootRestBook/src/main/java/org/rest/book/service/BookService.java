package org.rest.book.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.rest.book.entity.Book;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PutMapping;

@Component
public class BookService {
	private static List<Book> list = new ArrayList<>();
	static {
		list.add(new Book(1, "coe java", "priyadarsan", 567));
		list.add(new Book(2, "advanced java", "satish yadav", 235));
		list.add(new Book(3, "hibernate", "pabitra das", 123));
	}

//get all books
	public List<Book> getAllBooks() {
		return list;
	}

//get book by id
	public Book getBookById(int id) {
		// using stream api store book details
		Book book = null;
		book = list.stream().filter(e -> e.getId() == id).findFirst().get();
		return book;
	}
	//add book
	public void addBook(Book book) {
		list.add(book);
	}
	//update book
	public void UpdateBook(Book book, int bookId) {
		list=list.stream().map(b->{
			if(b.getId()==bookId) {
				
				b.setTitle(book.getTitle());
				b.setAuthor(book.getAuthor());
				b.setPages(book.getPages());
			}
			return b;
		}).collect(Collectors.toList());
	}
	//delete book
	public void deleteBook(int bId) {
		list=list.stream().filter(book ->book.getId()!=bId).collect(Collectors.toList());
		
	}
}
