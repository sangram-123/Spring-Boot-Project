package org.rest.book.controller;

import java.util.List;

import org.rest.book.entity.Book;
import org.rest.book.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookController {
	@Autowired
	private BookService bookservice;

	@GetMapping("/books")
//	public Book getBooks() {
//		Book book=new Book();
//		book.setId(1);
//		book.setTitle("springboot full course");
//		book.setAuthor("sangu");
//		book.setPages(456);
//		return book;
//	}
	// store in all books
	public List<Book> getBooks() {
		return this.bookservice.getAllBooks();
	}

	// particular id using book return
	@GetMapping("/books/{id}")
	public Book getBook(@PathVariable("id") int id) {
		return bookservice.getBookById(id);
	}

	// addin book
	@PostMapping("/books")
	public Book addBook(@RequestBody Book book) {
		this.bookservice.addBook(book);
		System.out.println(book);
		return book;

	}

	// deletebook
	@DeleteMapping("/books/{bookId}")
	public void deleteBook(@PathVariable("bookId") int bookId) {
		this.bookservice.deleteBook(bookId);
	}

	// updatebook
	@PutMapping("/books/{bookId}")
	public Book updateBook(@RequestBody Book book, @PathVariable("bookId") int bookId) {
		this.bookservice.UpdateBook(book, bookId);
		return book;
	}
}
