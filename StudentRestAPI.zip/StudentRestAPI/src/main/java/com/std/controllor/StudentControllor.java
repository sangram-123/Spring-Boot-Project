package com.std.controllor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.std.Repository.StudentRepository;
import com.std.entity.Studententity;

@RestController
public class StudentControllor {
	@Autowired
	StudentRepository repo;
//get all student
	@GetMapping("/students")
	public List<Studententity> getAllStudent(){
		List<Studententity> students=repo.findAll();
		return students;
	}
	//get student based on particular id
	@GetMapping("/students/{id}")
	public Studententity getStudent(@PathVariable int id) {
		Studententity student=repo.findById(id).get();
		return student;
		
	}
	@PostMapping("/students/add")
	@ResponseStatus(code = HttpStatus.CREATED)// status changed
	public void creatStudent(@RequestBody Studententity student) {
		repo.save(student);
		
	}
	@PutMapping("/students/update/{id}")
	@ResponseStatus(code = HttpStatus.CREATED)// status changed
	public void updateStudent( @RequestBody Studententity student  ,@PathVariable int id) {
		repo.save(student);
		
	}
	@DeleteMapping("/students/delete/{id}")
	@ResponseStatus(code = HttpStatus.CREATED)// status changed
	public void deleteStudent(@PathVariable int id) {
		Studententity student=repo.findById(id).get();
		repo.deleteById(id);
		
	}
}
