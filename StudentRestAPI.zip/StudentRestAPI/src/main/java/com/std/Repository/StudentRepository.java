package com.std.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.std.entity.Studententity;

public interface StudentRepository  extends JpaRepository<Studententity, Integer>{

}
