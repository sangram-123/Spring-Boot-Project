package com.std.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Student")
public class Studententity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int rollnumber;
	@Column(name = "stud_name")
	private String sname;
	@Column(name = "stud_per")
	private float percentage;
	@Column(name = "stud_branch")
	private String branch;

	public Studententity() {
		// TODO Auto-generated constructor stub
	}

	public Studententity( String sname, float percentage, String branch) {
		super();
		this.sname = sname;
		this.percentage = percentage;
		this.branch = branch;
	}

	public int getRollnumber() {
		return rollnumber;
	}

	public void setRollnumber(int rollnumber) {
		this.rollnumber = rollnumber;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public float getPercentage() {
		return percentage;
	}

	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	@Override
	public String toString() {
		return "Studententity [rollnumber=" + rollnumber + ", sname=" + sname + ", percentage=" + percentage
				+ ", branch=" + branch + "]";
	}

}
