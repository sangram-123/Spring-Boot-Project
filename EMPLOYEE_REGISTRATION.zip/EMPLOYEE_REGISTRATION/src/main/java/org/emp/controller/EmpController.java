package org.emp.controller;

import java.util.List;

import org.emp.entity.Employee;
import org.emp.service.EmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class EmpController {
	@Autowired
	private EmpService service;

	@GetMapping("/")
	public String home(Model m) {
		List<Employee> emp = service.getAllEmp();
		m.addAttribute("emp", emp);
		return "index";
	}

	@GetMapping("/addemp")
	public String AddEmpForm() {
		return "add_emp";
	}

	@PostMapping("/register")
	public String EmpRegister(@ModelAttribute("e") Employee e, HttpSession session) {

		this.service.AddEmp(e);
		session.setAttribute("msg", "Employee sucessfully added..");

		System.out.println(e);
		return "redirect:/";
	}

	@GetMapping("/edit/{Id}")
	public String edit(@PathVariable int Id, Model m) {
		Employee e = service.getEmpById(Id);
		m.addAttribute("emp", e);
		return "edit";
	}

	@PostMapping("/update")
	public String Update(@ModelAttribute Employee e, HttpSession session) {
		service.AddEmp(e);
		session.setAttribute("msg", "update sucessfully..");
		return "redirect:/";

	}

	@GetMapping("/delete/{Id}")
	public String Delete(@PathVariable int Id, HttpSession session) {
		service.DeleteEmp(Id);
		session.setAttribute("msg", "deleted data sucessully!!");
		return "redirect:/";
	}
}
