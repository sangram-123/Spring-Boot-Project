package org.emp.service;

import java.util.List;
import java.util.Optional;

import org.emp.Repository.EmpRepo;
import org.emp.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmpService {
	@Autowired
	private EmpRepo repo;

	public void AddEmp(Employee e) {
		this.repo.save(e);
	}

	public List<Employee> getAllEmp() {
		return repo.findAll();
	}
	public Employee getEmpById( int Id) {
		Optional<Employee> e = repo.findById(Id);
		if(e.isPresent()) {
			return e.get();
		}
		return null;
	}
	public void DeleteEmp(int Id) {
		repo.deleteById(Id);
	}
}
